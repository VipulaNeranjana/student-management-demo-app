package lk.ijse.dep10.smsspringbootbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmsSpringbootBackEndApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmsSpringbootBackEndApplication.class, args);
	}

}
